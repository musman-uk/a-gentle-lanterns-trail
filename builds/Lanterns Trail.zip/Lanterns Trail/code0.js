gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDFull_9595moonObjects1= [];
gdjs.Game_32SceneCode.GDFull_9595moonObjects2= [];
gdjs.Game_32SceneCode.GDLanternObjects1= [];
gdjs.Game_32SceneCode.GDLanternObjects2= [];
gdjs.Game_32SceneCode.GDStreet_9595SignObjects1= [];
gdjs.Game_32SceneCode.GDStreet_9595SignObjects2= [];
gdjs.Game_32SceneCode.GDCartObjects1= [];
gdjs.Game_32SceneCode.GDCartObjects2= [];
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects1= [];
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects2= [];
gdjs.Game_32SceneCode.GDHouseObjects1= [];
gdjs.Game_32SceneCode.GDHouseObjects2= [];
gdjs.Game_32SceneCode.GDGroundObjects1= [];
gdjs.Game_32SceneCode.GDGroundObjects2= [];
gdjs.Game_32SceneCode.GDSkyObjects1= [];
gdjs.Game_32SceneCode.GDSkyObjects2= [];
gdjs.Game_32SceneCode.GDTrailObjects1= [];
gdjs.Game_32SceneCode.GDTrailObjects2= [];
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects1= [];
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects2= [];
gdjs.Game_32SceneCode.GDStarsObjects1= [];
gdjs.Game_32SceneCode.GDStarsObjects2= [];
gdjs.Game_32SceneCode.GDCart_9595WheelObjects1= [];
gdjs.Game_32SceneCode.GDCart_9595WheelObjects2= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects = Hashtable.newFrom({"Cart": gdjs.Game_32SceneCode.GDCartObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects = Hashtable.newFrom({"Cart": gdjs.Game_32SceneCode.GDCartObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects = Hashtable.newFrom({"Cart": gdjs.Game_32SceneCode.GDCartObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects = Hashtable.newFrom({"Cart": gdjs.Game_32SceneCode.GDCartObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHouseObjects1Objects = Hashtable.newFrom({"House": gdjs.Game_32SceneCode.GDHouseObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cart"), gdjs.Game_32SceneCode.GDCartObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cart_Wheel"), gdjs.Game_32SceneCode.GDCart_9595WheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lantern"), gdjs.Game_32SceneCode.GDLanternObjects1);
gdjs.copyArray(runtimeScene.getObjects("Trail"), gdjs.Game_32SceneCode.GDTrailObjects1);
{gdjs.evtTools.sound.playMusic(runtimeScene, "night-background-sound.mp3", true, 40, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCart_9595WheelObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCart_9595WheelObjects1[i].getBehavior("Sticker").Stick(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLanternObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLanternObjects1[i].getBehavior("Sticker").Stick(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTrailObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTrailObjects1[i].getBehavior("Sticker").Stick(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cart"), gdjs.Game_32SceneCode.GDCartObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCartObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCartObjects1[i].getBehavior("SmoothCamera").MoveCameraCloser(null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) < 640;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 640, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) > 5360;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 5360, "", 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cart"), gdjs.Game_32SceneCode.GDCartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCartObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDCartObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCartObjects1[k] = gdjs.Game_32SceneCode.GDCartObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCartObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCartObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDCartObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDCartObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCartObjects1[k] = gdjs.Game_32SceneCode.GDCartObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCartObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13401164);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCartObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCartObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCartObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDCartObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "trolley-moving-sound.mp3", 1, true, 25, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cart"), gdjs.Game_32SceneCode.GDCartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCartObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDCartObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCartObjects1[k] = gdjs.Game_32SceneCode.GDCartObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCartObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCartObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDCartObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDCartObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCartObjects1[k] = gdjs.Game_32SceneCode.GDCartObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCartObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCartObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCartObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCartObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDCartObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cart"), gdjs.Game_32SceneCode.GDCartObjects1);
gdjs.copyArray(runtimeScene.getObjects("House"), gdjs.Game_32SceneCode.GDHouseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCartObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHouseObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13403788);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCartObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "bell-sound.mp3", false, 25, 1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCartObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCartObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(0);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()) >= 7;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End_Scene", false);
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDFull_9595moonObjects1.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects2.length = 0;
gdjs.Game_32SceneCode.GDLanternObjects1.length = 0;
gdjs.Game_32SceneCode.GDLanternObjects2.length = 0;
gdjs.Game_32SceneCode.GDStreet_9595SignObjects1.length = 0;
gdjs.Game_32SceneCode.GDStreet_9595SignObjects2.length = 0;
gdjs.Game_32SceneCode.GDCartObjects1.length = 0;
gdjs.Game_32SceneCode.GDCartObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects2.length = 0;
gdjs.Game_32SceneCode.GDTrailObjects1.length = 0;
gdjs.Game_32SceneCode.GDTrailObjects2.length = 0;
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects1.length = 0;
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects2.length = 0;
gdjs.Game_32SceneCode.GDStarsObjects1.length = 0;
gdjs.Game_32SceneCode.GDStarsObjects2.length = 0;
gdjs.Game_32SceneCode.GDCart_9595WheelObjects1.length = 0;
gdjs.Game_32SceneCode.GDCart_9595WheelObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList0(runtimeScene);
gdjs.Game_32SceneCode.GDFull_9595moonObjects1.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects2.length = 0;
gdjs.Game_32SceneCode.GDLanternObjects1.length = 0;
gdjs.Game_32SceneCode.GDLanternObjects2.length = 0;
gdjs.Game_32SceneCode.GDStreet_9595SignObjects1.length = 0;
gdjs.Game_32SceneCode.GDStreet_9595SignObjects2.length = 0;
gdjs.Game_32SceneCode.GDCartObjects1.length = 0;
gdjs.Game_32SceneCode.GDCartObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595BuildingsObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects2.length = 0;
gdjs.Game_32SceneCode.GDTrailObjects1.length = 0;
gdjs.Game_32SceneCode.GDTrailObjects2.length = 0;
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects1.length = 0;
gdjs.Game_32SceneCode.GDInvisible_9595WallObjects2.length = 0;
gdjs.Game_32SceneCode.GDStarsObjects1.length = 0;
gdjs.Game_32SceneCode.GDStarsObjects2.length = 0;
gdjs.Game_32SceneCode.GDCart_9595WheelObjects1.length = 0;
gdjs.Game_32SceneCode.GDCart_9595WheelObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
