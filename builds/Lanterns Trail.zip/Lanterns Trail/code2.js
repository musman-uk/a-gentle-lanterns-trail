gdjs.About_95SceneCode = {};
gdjs.About_95SceneCode.localVariables = [];
gdjs.About_95SceneCode.idToCallbackMap = new Map();
gdjs.About_95SceneCode.GDAboutObjects1= [];
gdjs.About_95SceneCode.GDAboutObjects2= [];
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects1= [];
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects2= [];
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1= [];
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2= [];
gdjs.About_95SceneCode.GDSignatureObjects1= [];
gdjs.About_95SceneCode.GDSignatureObjects2= [];
gdjs.About_95SceneCode.GDLicenseObjects1= [];
gdjs.About_95SceneCode.GDLicenseObjects2= [];


gdjs.About_95SceneCode.mapOfGDgdjs_9546About_959595SceneCode_9546GDReturn_95959595To_95959595Menu_95959595ButtonObjects1Objects = Hashtable.newFrom({"Return_To_Menu_Button": gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1});
gdjs.About_95SceneCode.mapOfGDgdjs_9546About_959595SceneCode_9546GDSignatureObjects1Objects = Hashtable.newFrom({"Signature": gdjs.About_95SceneCode.GDSignatureObjects1});
gdjs.About_95SceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Return_To_Menu_Button"), gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.About_95SceneCode.mapOfGDgdjs_9546About_959595SceneCode_9546GDReturn_95959595To_95959595Menu_95959595ButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Signature"), gdjs.About_95SceneCode.GDSignatureObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.About_95SceneCode.mapOfGDgdjs_9546About_959595SceneCode_9546GDSignatureObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://github.com/musman-uk", runtimeScene);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
}

}


};

gdjs.About_95SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.About_95SceneCode.GDAboutObjects1.length = 0;
gdjs.About_95SceneCode.GDAboutObjects2.length = 0;
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects1.length = 0;
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects2.length = 0;
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length = 0;
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2.length = 0;
gdjs.About_95SceneCode.GDSignatureObjects1.length = 0;
gdjs.About_95SceneCode.GDSignatureObjects2.length = 0;
gdjs.About_95SceneCode.GDLicenseObjects1.length = 0;
gdjs.About_95SceneCode.GDLicenseObjects2.length = 0;

gdjs.About_95SceneCode.eventsList0(runtimeScene);
gdjs.About_95SceneCode.GDAboutObjects1.length = 0;
gdjs.About_95SceneCode.GDAboutObjects2.length = 0;
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects1.length = 0;
gdjs.About_95SceneCode.GDGame_9595DescriptionObjects2.length = 0;
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length = 0;
gdjs.About_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2.length = 0;
gdjs.About_95SceneCode.GDSignatureObjects1.length = 0;
gdjs.About_95SceneCode.GDSignatureObjects2.length = 0;
gdjs.About_95SceneCode.GDLicenseObjects1.length = 0;
gdjs.About_95SceneCode.GDLicenseObjects2.length = 0;


return;

}

gdjs['About_95SceneCode'] = gdjs.About_95SceneCode;
