gdjs.Main_95MenuCode = {};
gdjs.Main_95MenuCode.localVariables = [];
gdjs.Main_95MenuCode.idToCallbackMap = new Map();
gdjs.Main_95MenuCode.GDGame_9595TitleObjects1= [];
gdjs.Main_95MenuCode.GDGame_9595TitleObjects2= [];
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects1= [];
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects2= [];
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects1= [];
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects2= [];


gdjs.Main_95MenuCode.mapOfGDgdjs_9546Main_959595MenuCode_9546GDPlay_95959595ButtonObjects1Objects = Hashtable.newFrom({"Play_Button": gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects1});
gdjs.Main_95MenuCode.mapOfGDgdjs_9546Main_959595MenuCode_9546GDAbout_95959595ButtonObjects1Objects = Hashtable.newFrom({"About_Button": gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects1});
gdjs.Main_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play_Button"), gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_9546Main_959595MenuCode_9546GDPlay_95959595ButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Button"), gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_9546Main_959595MenuCode_9546GDAbout_95959595ButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "About_Scene", false);
}
}

}


};

gdjs.Main_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_95MenuCode.GDGame_9595TitleObjects1.length = 0;
gdjs.Main_95MenuCode.GDGame_9595TitleObjects2.length = 0;
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects1.length = 0;
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects2.length = 0;
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects1.length = 0;
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects2.length = 0;

gdjs.Main_95MenuCode.eventsList0(runtimeScene);
gdjs.Main_95MenuCode.GDGame_9595TitleObjects1.length = 0;
gdjs.Main_95MenuCode.GDGame_9595TitleObjects2.length = 0;
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects1.length = 0;
gdjs.Main_95MenuCode.GDPlay_9595ButtonObjects2.length = 0;
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects1.length = 0;
gdjs.Main_95MenuCode.GDAbout_9595ButtonObjects2.length = 0;


return;

}

gdjs['Main_95MenuCode'] = gdjs.Main_95MenuCode;
