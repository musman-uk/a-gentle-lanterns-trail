gdjs.End_95SceneCode = {};
gdjs.End_95SceneCode.localVariables = [];
gdjs.End_95SceneCode.idToCallbackMap = new Map();
gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1= [];
gdjs.End_95SceneCode.GDAppreciation_9595TextObjects2= [];
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1= [];
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2= [];
gdjs.End_95SceneCode.GDParting_9595TextObjects1= [];
gdjs.End_95SceneCode.GDParting_9595TextObjects2= [];


gdjs.End_95SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Return_To_Menu_Button"), gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1);
{for(var i = 0, len = gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EndGameTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndGameTimer") >= 1.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13520532);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Appreciation_Text"), gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1);
{for(var i = 0, len = gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1[i].getBehavior("Text").setText("This lantern appreciates you taking the time to guide it home...");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndGameTimer") >= 5.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13522196);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Parting_Text"), gdjs.End_95SceneCode.GDParting_9595TextObjects1);
{for(var i = 0, len = gdjs.End_95SceneCode.GDParting_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_95SceneCode.GDParting_9595TextObjects1[i].getBehavior("Text").setText("As the trail comes to an end here for now...");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndGameTimer") >= 9.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13523780);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Return_To_Menu_Button"), gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1);
{for(var i = 0, len = gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Return_To_Menu_Button"), gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1[k] = gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}
}

}


};

gdjs.End_95SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1.length = 0;
gdjs.End_95SceneCode.GDAppreciation_9595TextObjects2.length = 0;
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length = 0;
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2.length = 0;
gdjs.End_95SceneCode.GDParting_9595TextObjects1.length = 0;
gdjs.End_95SceneCode.GDParting_9595TextObjects2.length = 0;

gdjs.End_95SceneCode.eventsList0(runtimeScene);
gdjs.End_95SceneCode.GDAppreciation_9595TextObjects1.length = 0;
gdjs.End_95SceneCode.GDAppreciation_9595TextObjects2.length = 0;
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects1.length = 0;
gdjs.End_95SceneCode.GDReturn_9595To_9595Menu_9595ButtonObjects2.length = 0;
gdjs.End_95SceneCode.GDParting_9595TextObjects1.length = 0;
gdjs.End_95SceneCode.GDParting_9595TextObjects2.length = 0;


return;

}

gdjs['End_95SceneCode'] = gdjs.End_95SceneCode;
